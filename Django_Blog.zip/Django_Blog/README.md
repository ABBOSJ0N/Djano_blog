# Django_Blog
Har xil post qo'yadigan sayt
